<?php

header("Location: login");
