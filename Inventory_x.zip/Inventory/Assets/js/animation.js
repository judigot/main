//========================================MODULE/APP NAME========================================//

//====================GLOBAL VARIABLES====================//
//====================GLOBAL VARIABLES====================//

//====================GENERAL====================//
$(function () {
    $(document).on("mouseenter mouseout", ".boo", function (e) {
        $(this).toggleClass("flipY");
    });
    $(document).on("mouseenter mouseout", ".chopper", function (e) {
        $(this).toggleClass("rotate360");
    });
});
//====================GENERAL====================//

//====================FUNCTIONS====================//
//====================FUNCTIONS====================//

//========================================MODULE/APP NAME========================================//